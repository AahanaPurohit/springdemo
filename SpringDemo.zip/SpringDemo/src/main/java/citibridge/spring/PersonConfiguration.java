package citibridge.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import citibridge.SpringDemo.Employee;
import citibridge.SpringDemo.Employer;
import citibridge.SpringDemo.Person;

@Configuration
@ComponentScan(value={"citibridge.spring"})
public class PersonConfiguration {

	@Bean
	public Person getEmployee()
	{
		return new Employee();
		
	}
	
}
