package citibridge.spring;


import citibridge.SpringDemo.Person;
public class MyXmlApplication {

	private Person person;
	
	public void setPerson(Person person) {
		this.person = person;
	}

	public void addPerson(String name)
	{
		this.person.addPerson(name);
		
	}
	
}
