package citibridge.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import citibridge.SpringDemo.Person;

@Component 
public class MyApplication {

	private Person person;
	
	@Autowired
	public void setPerson(Person person) {
		this.person = person;
	}

	public void addPerson(String name)
	{
		this.person.addPerson(name);
		
	}
	
}
