package citibridge.SpringDemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import citibridge.spring.MyXmlApplication;

/**
 * Hello world!
 *
 */
public class App2 
{
    public static void main( String[] args )
    {
    	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContextConfig.xml");
    	MyXmlApplication app = context.getBean(MyXmlApplication.class);
    	app.addPerson("Shweta");
    	context.close();
    }
}
