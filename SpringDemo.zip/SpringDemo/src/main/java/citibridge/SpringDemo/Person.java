package citibridge.SpringDemo;

public interface Person {

	public void addPerson(String name);
	
	
}
