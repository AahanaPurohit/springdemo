package citibridge.SpringDemo;

public class Employee implements Person {

	
	public void addPerson(String name) {
		System.out.println("Employee "+ name + "is added..");
	}

}
