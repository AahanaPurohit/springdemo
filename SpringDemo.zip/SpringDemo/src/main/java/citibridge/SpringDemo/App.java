package citibridge.SpringDemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import citibridge.spring.MyApplication;
import citibridge.spring.PersonConfiguration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext  context= new AnnotationConfigApplicationContext(PersonConfiguration.class) ;
    	MyApplication app = context.getBean(MyApplication.class);
    	app.addPerson("Shweta");
    	context.close();
    }
}
