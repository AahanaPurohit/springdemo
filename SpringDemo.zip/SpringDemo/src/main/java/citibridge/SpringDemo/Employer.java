package citibridge.SpringDemo;

public class Employer implements Person {

	
	public void addPerson(String name) {
		System.out.println("Employer "+name + " is added..");
	}

}
